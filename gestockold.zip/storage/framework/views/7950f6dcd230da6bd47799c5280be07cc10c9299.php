
                    
    <div class="form-group">
        <label for="libelecole">Nom de l'Ecole</label>
        <input type="text" name="libelecole" class="form-control my-2 <?php if(!empty($errors->has('libelecole'))): ?> is-invalid <?php endif; ?> " value="<?php echo e((!empty($ecole)) ? $ecole->libelecole : old('libelecole')); ?>" id="libelecole" placeholder="Entrez le nom de l'ecole">
        
        <?php if(!empty($errors->has('libelecole'))): ?>
        <div class="invalid-feedback">
            <?php echo e($errors->first('libelecole')); ?>

        </div>
        <?php endif; ?>
    </div>

    <button type="submit" class="btn btn-primary mr-2">VALIDER</button>

