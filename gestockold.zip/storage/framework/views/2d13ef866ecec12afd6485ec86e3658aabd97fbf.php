<?php $__env->startSection('content'); ?>

<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
             <?php if((Auth::user()->role === 1) || ( Auth::user()->role === 0  ) ): ?>
               <div class="card col-md-12  mb-5  grid-margin grid-margin-md-0 stretch-card">
                    <div class="card-body ">
                        <h4 class="card-title">Cotisaton du Membre </h4>
                        <div class="row">
                          <div class="col-md-12">
                                <span id="form_result"></span>
                                <form action="<?php echo e(route('paiementCotisationExceptionnel.store')); ?>" method="POST" class="form-sample" id ="sample_id" >
                                    <?php echo csrf_field(); ?>
                                    <?php echo $__env->make('paiementCotisationExceptionnel/form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <button class="btn btn-primary" type="submit">  valider </button>
                                </form>
                        
                            </div>
                        </div>
                    </div>
                </div>
             <?php endif; ?>
                <div class="card col-md-12">
                  <div class="card-body">
                    <h4 class="card-title">Détails  des paiements de la cotisation Exceptionnelle de <?php echo e($infoCotisationExceptionnel->member->nom); ?> <?php echo e($infoCotisationExceptionnel->member->prenoms); ?>  pour   <?php echo e($infoCotisationExceptionnel->objet); ?> </h4>
                    <!--<button class="mb-3 btn btn-success" data-toggle="modal" data-target="#paiementExceptionnelModal">Effectuer un paiement</button>-->
                    <div class="row">
                      <div class="col-md-12">
                       <div class="row">
                           <div class="table-responsive">
                               <table class="table table-bordered table-hover table-sm center" id="example2">
                                    <thead>
                                        <tr class="bg-secondary">
                                            <th>Nom du membre</th>
                                            <th>Montant</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $cotisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cotisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                <td><?php echo e($cotisation->nom); ?> <?php echo e($cotisation->prenoms); ?> </td>
                                                <td><?php echo e($cotisation->montant); ?> FCFA</td>
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot class="bg-secondary">
                                            <tr>
                                                <th>Montant Total:</th>
                                                <th><?php echo e($montantTotalCotisation); ?> FCFA</th>
                                            </tr>
                                    </tfoot>
                               </table>
                                
                           </div>
                       </div>
                        
                       
                        </div>
                    </div>
                  </div>
                </div>
              </div>

             
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>