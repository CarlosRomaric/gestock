<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="card">
                  <div class="card-body">
                    <?php if(session('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <button type="button" class="close" aria-label="Close" id="close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                          <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <h3 class="card-title text-center text-uppercase mb-5">Liste des bon de sorties</h3>
                    <?php if(Auth::user()->role==0): ?>
                     <a href="<?php echo e(route('sortie.sortieProduit')); ?>" class="btn btn-primary mb-3">Faire une sortie de produit</a>
                    <?php endif; ?>
                     <div class="row">
                      <div class="col-12 table-responsive">
                          <table class="table table-bordered table-hover table-sm center" id="example2">
                            <thead >
                                <tr class="bg-secondary">
                                    <th>N°</th>
                                    <th class="text-center">Technicien</th>
                                    <th class="text-center">Utlisateur</th>
                                    
                                    <th class="text-center">Numero OT</th>
                                    <th class="text-center">Date</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>

                                    <?php $__currentLoopData = $sorties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sortie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($sortie->id); ?></td>
                                            <td class="text-center"><?php echo e($sortie->technicien->nom); ?> <?php echo e($sortie->technicien->prenoms); ?></td>
                                            <td class="text-center text-uppercase"><?php echo e($sortie->user->name); ?>  </td>
                                            
                                            <td class="text-center text-uppercase"><?php echo e($sortie->numberOT); ?>  </td>

                                            <td class="text-center"><?php echo e($sortie->date->format('d/m/Y')); ?> </td>
                                            <td class="text-center">
                                                <!--<a href="#" class="btn btn-sm btn-warning"> <i class="icon-eye"></i> </a>-->
                                                <?php
                                                switch ($sortie->status) {
                                                case 0:
                                                    echo '<button class="btn badge badge-warning btn-sm">en attente </button>';
                                                    break;
                                                case 1:
                                                    echo '<button class="btn badge badge-success btn-sm">Validé </button>';
                                                    break;
                                                 case 2:
                                                    echo '<button class="btn badge badge-danger btn-sm">Rejeter </button>';
                                                    break;
                                               }?>
                                                
                                            </td>
                                            <td class="text-center">
                                                    <a href="sorties/<?php echo e($sortie->id); ?>" class="btn btn-warning" title="Voir les détails du bon de sortie"><i class="icon-eye"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                          </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>