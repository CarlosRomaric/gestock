<div class="form-group row">
    <label for="" id="" class="col-sm-3">Numero OT</label>
    <div class="col-sm-9">
        <input type="text"  class="form-control" name="numberOT" placeholder="Entrez le numero OT">
    </div>
</div>

<div class="form-group row">
    <label for="technicien_id" class="col-sm-3 col-form-label">Nom de l'Utilisateur</label>
    <div class="col-sm-9">
        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
        <input type="hidden" name="date" value="<?php echo e(date('Y-m-d H:i:s')); ?>">
        <select name="technicien_id"  class="js-example-basic-single w-100 " id="">
                    <option value="">Selectionner l'utilisateur</option>
                    <?php $__currentLoopData = $techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $technicien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" ><?php echo e($technicien); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        <?php if(!empty($errors->has('technicien_id'))): ?>
        <div class="alert alert-danger mt-4">
            <?php echo e($errors->first('technicien_id')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>

<div class="form-group row">
    <label for="superviseur_id" class="col-sm-3 col-form-label">Nom du Validateur</label>
    <div class="col-sm-9">
        
        <input type="hidden" name="date" value="<?php echo e(date('Y-m-d H:i:s')); ?>">
        <select name="superviseur_id"  class="js-example-basic-single w-100 " id="">
                    <option value="">Selectionnez le validateur</option>
                      <?php $__currentLoopData = $superviseurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $superviseur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($superviseur->id); ?>"><?php echo e($superviseur->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        <?php if(!empty($errors->has('supervisuer_id'))): ?>
        <div class="alert alert-danger mt-4">
            <?php echo e($errors->first('superviseur_id')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>


