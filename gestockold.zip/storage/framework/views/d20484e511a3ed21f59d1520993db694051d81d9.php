<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="card">
                  <div class="card-body">
                    <?php if(session('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <button type="button" class="close" aria-label="Close" id="close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                          <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <h3 class="card-title text-center mb-5">Liste des Articles</h3>
                     <?php if(Auth::user()->role==0): ?>
                     <a href="<?php echo e(route('produits.create')); ?>" class="btn btn-primary mb-3">Ajouter un  Article</a>
                     <?php endif; ?>
                     <div class="row">
                      <div class="col-12 table-responsive">
                          <table class="table table-bordered table-hover table-sm center" id="example2">
                            <thead >

                                <tr class=" bg-secondary">
                                    <th>N°</th>
                                    <?php if(Auth::user()->role==0): ?>
                                    <th class="text-center">Actions</th>
                                    <?php endif; ?>
                                    <th class="">Image</th>
                                    <th class="">Reférence</th>
                                    <th class="">Designation</th>
                                    <th class="">Magasin</th>
                                    <th class="">Etagere</th>
                                    <th class="">Rangée</th>
                                    <th class="">Prix Achat</th>
                                    <th class="">Prix de vente</th>
                                    <th class="">Stock</th>
                                    <th class="">Seuil d'alerte</th>
                                    <th class="">Famille</th>
                                    <th class="">Marque</th>
                                    <th class="">Modèle</th>
                                    <th class="">Fournisseur</th>

                                </tr>
                            </thead>
                            <tbody>
                                    <?php $i=0; ?>
                                    <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $i++; ?>
                                        <tr class="text-center">
                                            <td><?php echo e($i); ?></td>
                                            <?php if(Auth::user()->role==0): ?>
                                            <td class="text-center">
                                                 <a class="btn btn-warning btn-sm" href="/produits/<?php echo e($produit->id); ?>" title="Détail du produit">
                                                    <i class="icon-eye"></i>
                                                </a>
                                                <a class="btn btn-primary btn-sm" href="/produits/<?php echo e($produit->id); ?>/edit" title="modifié les info du produits">
                                                    <i class="icon-note"></i>
                                                </a>
                                                <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#mb-delete_<?php echo e($produit->id); ?>"><i class=" icon-trash"></i></button>
                                            </td>
                                            <?php endif; ?>
                                            <td class="">
                                                <img src="/images_produits/<?php echo e($produit->image); ?>" alt="">

                                            </td>
                                            <td class=""><?php echo e($produit->ref); ?> </td>
                                            <td class=""><?php echo e($produit->designation); ?> </td>
                                            <td class=""><?php echo e($produit->magasin); ?> </td>
                                            <td class=""><?php echo e($produit->etagere); ?></td>
                                            <td class=""><?php echo e($produit->rangee); ?></td>
                                            <td class=""><?php echo e(getPrice($produit->price)); ?> </td>
                                            <td class=""><?php echo e(getPrice($produit->priceSeller)); ?> </td>
                                            <td class=""><?php echo e($produit->qteStock); ?> </td>
                                            <td class=""><?php echo e($produit->qteMin); ?> </td>
                                            <td class=""><?php echo e($produit->famille->libelle); ?></td>
                                            <td class=""><?php echo e($produit->famille->marque); ?></td>
                                            <td class=""><?php echo e($produit->famille->modele); ?></td>
                                            <td class=""><?php echo e($produit->fournisseur->nom); ?> </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                          </table>
                          <a href="<?php echo e(route('pdf.listingProduits')); ?>" class="btn btn-success my-3 "><i class="icon-printer"></i>Imprimer la liste Articles</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>



            <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="mb-delete_<?php echo e($produit->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteLabel">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title login-title" id="myModalLabel">Supprimer <?php echo e($produit->ref); ?> <?php echo e($produit->designation); ?></h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

                            </div>
                            <div class="modal-body">
                                <p>La suppression est irréverssible!!!.
                                    Voulez-vous vraiment Supprimer cetle ligne?</p>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-default" data-dismiss="modal" type="button">
                                    <i class="fa fa-reply"></i> Annuler
                                </button>

                                <form action ="<?php echo e(route('produits.destroy', $produit->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-success">
                                        <i class="fa fa-save"></i> Valider
                                    </button>
                                    <input type="hidden" name="_method" value="DELETE">

                                 </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>