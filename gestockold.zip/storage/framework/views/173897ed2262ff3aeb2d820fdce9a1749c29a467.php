 <div class="row">
    <div class="col-md-6">
        <div class="form-group row">
            <lablel for="beneficiaireMember_id" class="col-sm-3 col-form-label">Nom du beneficiaire</lablel>
            <div class="col-sm-9">
                <select class="js-example-basic-single w-100 " name="beneficiaireMember_id">
                    <option value="">Ajouter un payeur</option>
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($member->id); ?>"><?php echo e($member->nom); ?> <?php echo e($member->prenoms); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                        
        </div>
    </div>
    </div>
    <div class="col-md-6">
        <div class="form-group row">
            <label for="montant" class="col-sm-3 col-form-label">Montant</label>
            <div class="col-sm-9">
                <input type="text" name="montant"    onkeypress="chiffres(event)" class="form-control" value="<?php echo e(old('montant')); ?>" placeholder="Entrez le montant de la cotisation du membre">
                <br>
                <?php if(!empty($errors->has('montant'))): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first('montant')); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>

        <input type="hidden"  name="member_id" value="<?php echo e($infoCotisationExceptionnel->member->id); ?>">
        <input type="hidden"  name="cotisationExceptionnel_id" value="<?php echo e($infoCotisationExceptionnel->id); ?>">
    </div>

 </div>  
 

       


