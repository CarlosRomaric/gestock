
                    
    <div class="form-group">
        <label for="libelpiece">libellé</label>
        <input type="text" name="libelpiece" class="form-control my-2 <?php if(!empty($errors->has('libelpiece'))): ?> is-invalid <?php endif; ?> " value="<?php echo e((!empty($pieceIdentites)) ? $pieceIdentites->libelpiece : old('libelpiece')); ?>" id="libelpiece" placeholder="Entrez le libellé de la pièce">
        
        <?php if(!empty($errors->has('libelpiece'))): ?>
        <div class="invalid-feedback">
            <?php echo e($errors->first('libelpiece')); ?>

        </div>
        <?php endif; ?>
    </div>

    <button type="submit" class="btn btn-primary mr-2">Valider</button>

