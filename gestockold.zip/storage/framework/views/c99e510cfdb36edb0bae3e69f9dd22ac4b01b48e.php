<?php $__env->startSection('content'); ?>
 <div class="container-scroller">
<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="container-fluid page-body-wrapper">
    <div class="main-panel">
    <div class="content-wrapper">
          <div class="row">
            <div class="col-md-12  grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Liste de Pieces d'Identités</h4>
                  <p class="card-description">
                    <a href="<?php echo e(route('pieceIdentite.create')); ?>" class="btn btn-primary">AJOUTER</a>
                  </p>
                  <div class="table-responsive">
                    <table class="table table-boredered" id="order-listing">
                        <thead>
                            <tr>
                                <th>N°</th>
                                <th>Piece</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                             <?php $i=0; ?>
                             <?php $__currentLoopData = $pieceIdentites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pieceIdentite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php  $i++; ?>
                            <tr>
                                <td> <?php echo e($i); ?>  </td>
                                <td> <?php echo e($pieceIdentite->libelpiece); ?> </td>
                                <td> 
                                    <a href="<?php echo e(route('pieceIdentite.edit', $pieceIdentite->id)); ?>" class="btn btn-primary">Modifier</a>
                                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#mb-delete_<?php echo e($pieceIdentite->id); ?>">
                                    Suppirmer
                                    </button>
                                    
                                    
                                 </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                     

                        
                    </table>
                  </div>

                  
                   
                </div>
              </div>
            </div>
           
          </div>
        </div>

    <?php echo $__env->make('inc/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>


  <?php $__currentLoopData = $pieceIdentites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pieceIdentite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="modal fade" id="mb-delete_<?php echo e($pieceIdentite->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteLabel">
                  <div class="modal-dialog" role="document">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h4 class="modal-title login-title" id="myModalLabel">Supprimer <?php echo e($pieceIdentite->libelpiece); ?></h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                              
                          </div>
                          <div class="modal-body">
                              <p>La suppression est irréverssible!!!.
                                  Voulez-vous vraiment supprimer cette ligne?</p>
                          </div>
                          <div class="modal-footer">
                              <button class="btn btn-default" data-dismiss="modal" type="button">
                                  <i class="fa fa-reply"></i> Annuler
                              </button>
                              


                               <form action="<?php echo e(route('pieceIdentite.destroy', $pieceIdentite->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-success">VALIDER</button>
                                </form>
                          </div>
                      </div>
                  </div>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>