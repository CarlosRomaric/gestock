
                    
    <div class="form-group">
        <label for="libelniveau">Libéllé du Niveau d'Etude</label>
        <input type="text" name="libelniveau" class="form-control my-2 <?php if(!empty($errors->has('libelniveau'))): ?> is-invalid <?php endif; ?> " value="<?php echo e((!empty($niveauxetude)) ? $niveauxetude->libelniveau : old('libelniveau')); ?>" id="libelniveau" placeholder="Entrez le libellé du Niveau d'Etude">
        
        <?php if(!empty($errors->has('libelniveau'))): ?>
        <div class="invalid-feedback">
            <?php echo e($errors->first('libelniveau')); ?>

        </div>
        <?php endif; ?>
    </div>

    <button type="submit" class="btn btn-primary mr-2">VALIDER</button>

