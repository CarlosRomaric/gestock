<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="card">
                  <div class="card-body">
                    <?php if(session('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <button type="button" class="close" aria-label="Close" id="close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                          <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <h3 class="card-title text-center mb-5">Detail du produit <?php echo e($produit->designation); ?></h3>
                     <a href="<?php echo e(route('produits.index')); ?>" class="btn btn-primary mb-3">Liste de Produits</a>
                    <div class="row">
                      <div class="col-12 table-responsive">
                          <table class="table table-bordered table-hover table-sm center" >
                            <thead >
                                   
                                <tr class=" bg-secondary">
                                    <th class="">Image</th>
                                    <th class="">Reférence</th>
                                    <th class="">Designation</th>
                                    <th class="">Brève description</th>
                                    <th class="">Description</th>
                                    <th class="">Prix unitaire</th>
                                    <th class="">Stock</th>
                                    <th class="">Seuil d'alerte</th>
                                    <th class="">Montant Total</th>
                                    <th class="">Famille</th>
                                    <th class="">Fournisseur</th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                                   
                                <tr class="text-center">
                                    
                                    <td class=""> <img src="/images_produits/<?php echo e($produit->image); ?>" alt=""></td>
                                    <td class=""><?php echo e($produit->ref); ?> </td>                                           
                                    <td class=""><?php echo e($produit->designation); ?> </td>                                            
                                    <td class=""><?php echo e($produit->subtitle); ?> </td>                                            
                                    <td class=""><?php echo e($produit->description); ?> </td>                                            
                                    <td class=""><?php echo e(getPrice($produit->price)); ?> </td>
                                    <td class=""><?php echo e($produit->qteStock); ?> </td>
                                    <td class=""><?php echo e($produit->qteMin); ?> </td>
                                    <td class=""><?php echo e(getPrice($produit->qteStock * $produit->price)); ?> </td>
                                    <td class=""><?php echo e($produit->famille->libelle); ?></td>
                                    <td class=""><?php echo e($produit->fournisseur->nom); ?>  </td>
                                   
                                </tr>
                                  
                            </tbody>
                          </table>
                      </div>
                      <div class="col-md-12 mt-5">
                          <button class="btn btn-success" data-toggle="modal" data-target="#entree">Entrée en stock</button>
                          <a href="<?php echo e(route('sortie.sortieProduit')); ?>" class="btn btn-danger"> Faire une Sortie</a>
                        <div class="row">
                             <div class="table-responsive mt-5 col-md-12">
                                 <p class=""><h4 class="text-center text-uppercase">Mouvement de <?php echo e($produit->designation); ?></h4></p>
                                <table class="table table-bordered table-hover table-sm " id="example2">
                                    <thead>
                                        <tr class="bg-secondary">
                                            <th>N°</th>
                                            <th>Quantité</th>
                                            <th>Date</th>
                                            <th>Magasinier</th>
                                            <th>Type</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php $i=0; ;?>
                                        <?php $__currentLoopData = $entrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <?php $i++; ;?>
                                        <tr>
                                            <td> <?php echo e($i); ?> </td>
                                            <td> <?php echo e($entree->qteStock); ?> </td>
                                            <td> <?php echo e($entree->date->format('d/m/Y')); ?> à <?php echo e($entree->date->format('H').' h '.$entree->date->format('i').' min '.$entree->date->format('s')); ?>  </td>
                                            <td> <?php echo e($entree->user->name); ?></td>
                                            <td>Entrée</td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                         <?php $__currentLoopData = $sorties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sortie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <?php $i++; ;?>
                                         
                                        <tr>
                                            <td> <?php echo e($i); ?> </td>
                                            <td> <?php echo e($sortie->qteStock); ?> </td>
                                            <td> <?php echo e($sortie->date->format('d/m/Y')); ?> à <?php echo e($sortie->date->format('H').' h '.$sortie->date->format('i').' min '.$sortie->date->format('s')); ?>  </td>
                                            <td> <?php echo e(App\User::getUserById( App\BonSortie::nomUserBySortie($sortie->bon_sorties_id)[0]->user_id )->name); ?></td>
                                            <td>Sortie</td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <!--<tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>Sortie</td>
                                        </tr>-->
                                    </tbody>
                                </table>
                             </div>
                             
                        </div>
                         
                      </div>
                    </div>
                  </div>
                </div>
              </div>
    
             

<div class="modal fade" id="entree" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="entreeLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="entreeLabel">Entrée en Stock du produit <?php echo e($produit->designation); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('entree.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
           <?php echo $__env->make('entree/form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Valider</button>
        </div>
      </form>
    </div>
  </div>
</div>
           
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>