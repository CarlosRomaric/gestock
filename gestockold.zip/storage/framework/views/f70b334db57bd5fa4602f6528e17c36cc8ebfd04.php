<?php $__env->startSection('content'); ?>

<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="card col-md-12">
                  <div class="card-body">
                    <h4 class="card-title">Liste des cotisations Exceptionnelles</h4>
                     <?php if((Auth::user()->role === 1) || ( Auth::user()->role === 0  ) ): ?>
                      <a href="/cotisationExceptionnel/create" class="mb-3 btn btn-success">Ajouter une Cotisation Exceptionnelle</a>
                     <?php endif; ?>
                    <div class="row">
                      <div class="col-md-12">
                       <div class="row">
                           <div class="table-responsive">
                               <table class="table table-bordered table-hover table-sm center" id="example2">
                                    <thead>
                                        <tr class="bg-secondary">
                                            <th>Objet</th>
                                            <th>Nom du Bénéficiaire</th>
                                            <th>Montant de la cotisation</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $cotisations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cotisation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                            
                                                <td><?php echo e($cotisation->objet); ?></td>
                                                <td><?php echo e($cotisation->member->nom); ?> <?php echo e($cotisation->member->prenoms); ?> </td>
                                                <td><?php echo e(App\PaiementCotisationExceptionnel::where('cotisationExceptionnel_id','=',$cotisation->id)->sum('montant')); ?> FCFA</td>
                                                <td class="text-center"> 
                                                    <a href="<?php echo e(route('paiementCotisationExceptionnel.index', $cotisation->id)); ?>" class="btn btn-info">Détails</a>
                                                </td>
                                            
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                               </table>
                              
                           </div>
                       </div>
                        
                       
                        </div>
                    </div>
                  </div>
                </div>
              </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>