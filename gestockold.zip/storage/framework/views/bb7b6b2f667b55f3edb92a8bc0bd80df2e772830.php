<?php $__env->startComponent('mail::message'); ?>
# Notification de validation de Bon de Sortie

<?php if($bonSortie->status == 1 ): ?>
    Le Bon se sortie N° <?php echo e($bonSortie->id); ?> a bien été validé.
    Voici la Remarque <?php echo e($bonSortie->remarque); ?>

<?php else: ?>
    Le Bon se sortie N° <?php echo e($bonSortie->id); ?> a  été Réjeté.
    Voici la Remarque <?php echo e($bonSortie->remarque); ?>

<?php endif; ?>

<?php $__env->startComponent('mail::button', ['url' => '/']); ?>
Retour sur Gestion des Stocks
<?php echo $__env->renderComponent(); ?>

Merci,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
