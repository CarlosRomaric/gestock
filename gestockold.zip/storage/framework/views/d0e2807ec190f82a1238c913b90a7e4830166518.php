<div class="row">
    <div class="col-md-6">
        <div class="form-group row">
          <label for="nom" class="col-sm-3 col-form-label">Nom</label>
          <div class="col-sm-9">
            <input type="text" name="nom"  id="nom" class="form-control" value="<?php echo e((empty($member)) ? old('nom') : $member->nom); ?>" placeholder="Entrez le nom du membre">
            <br>
            <?php if(!empty($errors->has('nom'))): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('nom')); ?>

            </div>
            <?php endif; ?>
         </div>
        </div>

        <div class="form-group row">
            <label for="contacts" class="col-sm-3 col-form-label">Contacts</label>
            <div class="col-sm-9">
                <input type="text" name="contacts" maxlength="8"  id="contacts" class="form-control" value="<?php echo e((empty($member)) ? old('contacts') : $member->contacts); ?>" onkeypress="chiffres(event)" placeholder="Entrez le contact du membre">
                <br>
                <?php if(!empty($errors->has('contacts'))): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first('contacts')); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row">
          <label for="profession" class="col-sm-3 col-form-label">profession</label>
          <div class="col-sm-9">
            <input type="text" name="profession"  id="profession" class="form-control" value="<?php echo e((empty($member)) ? old('profession') : $member->profession); ?>" placeholder="Entrez la profession du membre">
            <br>
            <?php if(!empty($errors->has('profession'))): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('profession')); ?>

            </div>
            <?php endif; ?>
         </div>
        </div>
    </div>

    <div class="col-md-6">

        <div class="form-group row">
            <label for="prenoms" class="col-sm-3 col-form-label">Prenoms</label>
            <div class="col-sm-9">
                <input type="text" name="prenoms"  id="prenoms" class="form-control" value="<?php echo e((empty($member)) ? old('prenoms') : $member->prenoms); ?>" placeholder="Entrez le prenom du membre">
                <br>
                <?php if(!empty($errors->has('prenoms'))): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first('prenoms')); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row">
          <label for="domicile" class="col-sm-3 col-form-label">Domicile</label>
          <div class="col-sm-9">
            <input type="text" name="domicile"  id="domicile" class="form-control" value="<?php echo e((empty($member)) ? old('domicile') : $member->domicile); ?>" placeholder="Entrez le domicile du membre">
            <br>
            <?php if(!empty($errors->has('domicile'))): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('domicile')); ?>

            </div>
            <?php endif; ?>
         </div>
        </div>

        <div class="form-group row">
          <label for="name" class="col-sm-3 col-form-label">Droits d'adhesion</label>
          <div class="col-sm-9">
            <input type="text" name="droitAdhesion"  id="droitAdhesion" class="form-control" value="<?php echo e((empty($member)) ? old('droitAdhesion') : $member->droitAdhesion); ?>" onkeypress="chiffres(event)" placeholder="Entrez le droit d'adehsion du membre">
            <br>
            <?php if(!empty($errors->has('droitAdhesion'))): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('droitAdhesion')); ?>

            </div>
            <?php endif; ?>
         </div>
         <input type="hidden" value="0" name="status">   
        </div>

    </div>

</div>















