<?php

namespace App\Http\Controllers;

use App\RetourStock;
use App\Technicien;
use App\Produit;
use App\Retour;
use Illuminate\Support\Arr;
use Illuminate\Http\Request;

class RetourStockController extends Controller
{
    protected $rules = [
        'user_id'=>'required',
        'technicien_id'=>'required'
    ];

    protected $messages = [
        'required'=>'Le Champ :attributes est requis'
    ];
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $retourStocks = RetourStock::listeRetourStocks();

        //dd($retourStocks);
        $data = [
            'retourStocks'=> $retourStocks
        ];
        return view('retourStocks/index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
            $techs = Technicien::listeTechniciens();
            //dd($techs);
            $tech =  [];
            foreach($techs as $t){
                $tech[$t->id] = $t->nom.' '.$t->prenoms;
            }
            //dd($tech);
            $techniciens = $tech;
            $produits = Produit::listeProduits();
        $data = [
            'techniciens'=>$techniciens,
            'produits'=>$produits
        ];
        return view('retourStocks/create')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dd($request->all());
        $this->validate($request, $this->rules, $this->messages);

        $data = RetourStock::getRequest($request);
        $dataRetourStock = Arr::except( $data, ['example2_length', 'produit_id', 'qteStock']);
        $dataproduits = Arr::except($data, ['example2_length', 'user_id', 'technicien_id','qteStock','_token']);
        $dataqtestock = Arr::except($data, ['example2_length', 'user_id', 'technicien_id', 'produit_id','_token']);
        $dataQteStock=[];
        $produits = [];
        foreach ($dataqtestock as $key => $value) {

            // }
            foreach ($value as $key2 => $v) {
              if($v != null){
                $dataQteStock[$key2] = $v;
              }
            }

        }
        foreach ($dataproduits as $key => $value) {
            foreach ($value as $key2 => $v) {
                  $dataproduits[$key2] = $v;
              }
        }
        $dataproduits = Arr::except($dataproduits, ['produit_id']);
        //dd($dataproduits, $dataQteStock);
        /**
         * Pour l'enregistrement dans la table retour en stocks on aura
         */
        //dd($dataRetourStock);
        RetourStock::create($dataRetourStock);
        $retourStocks_id = RetourStock::lastRecordRetourStocksId();

            foreach ($dataQteStock as $key => $value) {
                    $produit = Produit::find($key);
                    $qteStock = Produit::find($key)->qteStock;
                    $data = [
                        'produit_id'=>$key,
                        'retourStocks_id'=>$retourStocks_id,
                        'date'=>date('Y-m-d H:i:s'),
                        'qteStock'=> $value,
                    ];
                    $data2['qteStock'] = $qteStock + $value;
                    $produit->update($data2);
                    Retour::create($data);
            }

       return redirect('retourStocks')->with('message','Le retour en stock a bien été éffectué');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $retourStock = RetourStock::find($id);
        $retours = Retour::listeRetoursById($id);

        $data = [
            'retourStock'=>$retourStock,
            'retours'=>$retours
        ];

        return view('retourStocks/show')->with($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
