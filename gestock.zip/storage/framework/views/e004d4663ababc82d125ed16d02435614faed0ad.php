<div class="row">
        <div class="col col-md-6">
             <div class="form-group row">
                <label for="name" class="col-sm-4 col-form-label">Objet</label>
                <div class="col-sm-8">
                    <input type="text" name="objet"  id="objet" class="form-control" value="<?php echo e((empty($depenseSubvention)) ? old('objet') : $depenseSubvention->objet); ?>"  placeholder="Entrez l'objet de votre operation">
                    <br>
                    <?php if(!empty($errors->has('objet'))): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first('objet')); ?>

                    </div>
                    <?php endif; ?>
                </div> 
             </div>

             <div class="form-group row">
                <lablel for="type" class="col-sm-4 col-form-label">Type de l'operation</lablel>
                <div class="col-sm-8">
                    <select class="js-example-basic-single w-100 " name="type">
                        <option value="">Choisissez le type de votre Operation</option>
                       
                        <option value="depense"> Dépense </option>
                        <option value="subvention"> Subvention </option>
                       
                    </select>            
                </div>
            </div>
     </div>
    
     <div class="col-md-6">
             <div class="form-group row">
                <label for="name" class="col-sm-4 col-form-label">Montant</label>
                <div class="col-sm-8">
                    <input type="text" name="montant"  id="montant" onkeypress="chiffres(event)" class="form-control" value="<?php echo e((empty($depenseSubvention)) ? old('montant') : $depenseSubvention->montant); ?>"  placeholder="Entrez le montant de votre operation">
                    <br>
                    <?php if(!empty($errors->has('montant'))): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first('montant')); ?>

                    </div>
                    <?php endif; ?>
                </div> 
             </div>
     </div>
</div>
 
   
