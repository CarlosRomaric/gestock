<?php $__env->startSection('content'); ?>

<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container-scroller">
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">

            <div class="col-md-6 col-lg-3 grid-margin stretch-card">
              <div class="card bg-dark text-white border-0">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <i class="icon-handbag icon-lg"></i>
                    <div class="ml-4">
                      <h4 class="font-weight-light">Avoir Total en caisse</h4>
                      <h3 class="font-weight-light mb-3"><?php echo e($totalCaisse); ?> FCFA</h3>
                      <!--<p class="mb-0 font-weight-light">39% more growth </p>-->
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-6 col-lg-3 grid-margin stretch-card">
              <div class="card bg-primary text-white border-0">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <i class="icon-user icon-lg"></i>
                    <div class="ml-4">
                      <h4 class="font-weight-light">Utilisateurs</h4>
                      <h3 class="font-weight-light mb-3"><?php echo e($nbre_users); ?></h3>
                      <!--<p class="mb-0 font-weight-light">43% more this year </p>-->
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-6 col-lg-3 grid-margin stretch-card">
              <div class="card bg-danger text-white border-0">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <i class="icon-people icon-lg"></i>
                    <div class="ml-4">
                      <h4 class="font-weight-light">Membres</h4>
                      <h3 class="font-weight-light mb-3"><?php echo e($nbre_members); ?></h3>
                      <!--<p class="mb-0 font-weight-light">69% increase</p>-->
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-6 col-lg-3 grid-margin stretch-card">
                <div class="card bg-warning text-white border-0">
                  <div class="card-body">
                    <div class="d-flex align-items-center">
                      <i class=" icon-calendar icon-lg"></i>
                      <div class="ml-4">
                       
                        <h4 class="font-weight-light"><?= ucfirst(utf8_encode(strftime('%A', strtotime(date('d-m-Y'))))); ?></h4>
                        <h3 class="font-weight-light mb-3"><?= ucfirst(utf8_encode(strftime(' %d %B', strtotime(date('d-m-Y'))))); ?></h3>
                        <p class="mb-0 font-weight-light"><?= ucfirst(utf8_encode(strftime(' %Y ', strtotime(date('d-m-Y'))))); ?></p>
                      </div>
                    </div>
                  </div>
                </div>
             </div>
            </div>

            <div class="card my-4">
              <div class="card-body">
                <h4 class="card-title">Bienvenue dans votre Espace d'administration   <?php echo e(Auth::user()->name); ?>   </h4>
                <p class="text-center">
                    <h4>Détails des Avoirs</h4>
                </p>
                <div class="row">
                  <div class="col-12 table-responsive">
                    <table class="table table-bordered" id="example2">
                       <tr>
                          <td>Montant des cotisations exceptionnelles</td>
                          <td><?php echo e($totalCotisationExceptionnels); ?> FCFA</td>
                          
                       </tr>
                       <tr>
                          <td>Montant des cotisations Mensuelles</td>
                          <td><?php echo e($totalCotisationMensuelles); ?> FCFA</td>
                       </tr>
                       <tr>
                          <td>Montant des droits d'adhesions</td>
                          <td><?php echo e($droitAdhesion); ?> FCFA</td>
                       </tr>
                       <tr>
                           <td>Montant des Dépenses</td>
                          <td> <?php echo e($totalDepenses); ?> FCFA</td>
                       </tr>
                       <tr>
                           <td>Montant des Subventions</td>
                          <td> <?php echo e($totalSubventions); ?> FCFA</td>
                       </tr>
                    </table>
                  </div>
                </div>
              </div>
            </div>
         
        </div>
      

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>