<div class="row">

        <div class="col-md-6">
            <div class="form-group row">
                <label for="montant_regle" class="col-sm-3 col-form-label">Montant</label>
                <div class="col-sm-9">
                        <input type="text" name="montant_regle"  id="montant_regle"  onkeypress="chiffres(event)" class="form-control" value="<?php echo e((empty($cotisationMensuelle)) ? old('montant') : $cotisationMensuelle->montant); ?>" placeholder="Entrez le montant de la cotisation du membre">
                        <br>
                        <?php if(!empty($errors->has('montant_regle'))): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('montant_regle')); ?>

                        </div>
                        <?php endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="datePayement" class="col-sm-3 col-form-label">Date de paiement</label>
                <div class="col-sm-9">
                    <input type="date" name="datePayement"  id="datePayement"   class="form-control" value="<?php echo e((empty($cotisationMensuelle)) ? old('datePayement') : $cotisationMensuelle->datePayement); ?>" placeholder="Entrez le datePayement de la cotisation du membre">
                    <br>
                    <?php if(!empty($errors->has('datePayement'))): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first('datePayement')); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group row">
                <lablel for="Mois" class="col-sm-3 col-form-label">Mois</lablel>
                <div class="col-sm-9">
                    <select class="js-example-basic-single w-100" name="mois">
                        <option value="">Choisissez le mois</option>
                        <option value="JANVIER">JANVIER</option>
                        <option value="FEVRIER">FEVRIER</option>
                        <option value="MARS">MARS</option>
                        <option value="AVRIL">AVRIL</option>
                        <option value="MAI">MAI</option>
                        <option value="JUIN">JUIN</option>
                        <option value="JUILLET">JUILLET</option>
                        <option value="AOÛT">AOÛT</option>
                        <option value="SEPTEMBRE">SEPTEMBRE</option>
                        <option value="OCTOBRE">OCTOBRE</option>
                        <option value="NOVEMBRE">NOVEMBRE</option>
                        <option value="DECEMBRE">DECEMBRE</option>
                    </select>
                    <br>
                     <?php if(!empty($errors->has('mois'))): ?>
                    <div class="alert alert-danger mt-4">
                        <?php echo e($errors->first('mois')); ?>

                    </div>
                    <?php endif; ?>

                     <?php if(session('existmois')): ?>
                        <div class="alert alert-danger alert-dismissible fade show mt-4 text-center">
                            <button type="button" class="close" aria-label="Close" @click="close" id="close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                          <?php echo e(session('existmois')); ?>

                        </div>
                    <?php endif; ?>
                            
                </div>
            </div>
             <input type="hidden" name="reste_aregler" value="">
             <input type="hidden" name="member_id" value="<?php echo e($member->id); ?>">
        </div>




       
</div>

        