<?php $__env->startSection('content'); ?>

<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper ">
                <div class="">
                     <!--offset-md-2-->
                 <?php if( (Auth::user()->role === 0) || ( Auth::user()->role === 1)): ?>
                  <div class="card col-md-12  mb-5  grid-margin grid-margin-md-0 stretch-card">
                    <div class="card-body ">
                        <h4 class="card-title">Cotisaton du Membre </h4>
                        <?php if(session('message')): ?>
                            <div class="alert alert-success alert-dismissible fade show my-3 text-center">
                                <button type="button" class="close" aria-label="Close" @click="close" id="close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            <?php echo e(session('message')); ?>

                            </div>
                        <?php endif; ?>
                          
                                <span id="form_result"></span>
                                <form action="<?php echo e(route('cotisationMensuelle.store')); ?>" method="POST" class="form-sample" id ="sample_id" >
                                    <?php echo csrf_field(); ?>
                                    <?php echo $__env->make('members/formCotisationMensuelle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <button class="btn btn-primary" type="submit" id="action">Valider</button>
                                </form>
                        
                           
                       
                    </div>
                    
                  </div>
                 <?php endif; ?>
                    <div class="card col-md-12 ">
                        <div class="card-body">
                            <h4 class="card-title">Détails des cotisations Mensuelle de <?php echo e($member->nom); ?> <?php echo e($member->prenoms); ?></h4>
                            <div class="row">
                                <div class="col-md-12 table-responsive">
                                    <table class="table table-bordered  table-striped table-hover" id="example2">
                                        <thead>
                                         
                                            <tr>
                                                <th>N°</th>
                                                <th>Mois</th>
                                                <th>Montant</th>
                                                <th>Date de paiement</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; ?>
                                            <?php $__currentLoopData = $cotisationMensuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cotisationMensuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <?php $i++; ?>
                                                <tr>
                                                    <td><?php echo e($i); ?> </td>
                                                    <td><?php echo e($cotisationMensuelle->mois); ?></td>
                                                    <td><?php echo e($cotisationMensuelle->montant_regle); ?></td>
                                                    <td class="text-center">
                                                        <?php echo e($cotisationMensuelle->datePayement->format('d/m/Y')); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                            
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
           
            </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>