






<div class="form-group row">
    <label for="technicien_id" class="col-sm-3 col-form-label">Membres du staff</label>
    <div class="col-sm-9">

        <select name="technicien_id"  class="js-example-basic-single w-100 " id="">
            <option value="">Choisissez le Membre du staff</option>
            <?php $__currentLoopData = $techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technicien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($technicien->id); ?>" class="text-uppercase" ><?php echo e($technicien->nom); ?> <?php echo e($technicien->prenoms); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        <?php if(!empty($errors->has('technicien_id'))): ?>
        <div class="alert alert-danger mt-4">
            <?php echo e($errors->first('technicien_id')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>



<div class="form-group row">
          <label for="password" class="col-sm-3 col-form-label">Mot de passe</label>
          <div class="col-sm-9">
            <input type="password" name="password"  id="password" class="form-control" value="" placeholder="Entrez le mot de passe">
            <br>
            <?php if(!empty($errors->has('password'))): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('password')); ?>

            </div>
            <?php endif; ?>
         </div>
</div>

<div class="form-group row">
          <label for="password" class="col-sm-3 col-form-label">Confirmation du mot de passe</label>
          <div class="col-sm-9">
            <input type="password" name="password_confirmation"  id="password" class="form-control" value="" placeholder="confirmer le mot de passe">
            <br>
            <?php if(!empty($errors->has('password'))): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('password')); ?>

            </div>
            <?php endif; ?>
         </div>
</div>
<!--<div class="form-group form-check row ml-4">
        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
        <label class="form-check-label" for="remember">
            Se souvenir de moi
        </label>

</div>-->

<div class="form-group row">
 <label for="Libelle" class="col-sm-3 col-form-label">Role</label>
   <div class="col-sm-9">
        <select name="role" id="role" class="form-control" id="formselect2">
           <?php if((Auth::user()->role === 0)): ?>
            <option value="0">Admin</option>
           <?php endif; ?>
            
            <option value="2">Superviseur</option>
            <option value="3">utilisateur</option>
        </select>
    </div>
</div>
