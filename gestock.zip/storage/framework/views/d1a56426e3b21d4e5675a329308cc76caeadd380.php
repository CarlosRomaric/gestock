
                    
    <div class="form-group">
        <label for="libelserv">Nom du service</label>
        <input type="text" name="libelserv" class="form-control my-2 <?php if(!empty($errors->has('libelserv'))): ?> is-invalid <?php endif; ?> " value="<?php echo e((!empty($service)) ? $service->libelserv : old('libelserv')); ?>" id="libelserv" placeholder="Entrez le nom du service">
        
        <?php if(!empty($errors->has('libelserv'))): ?>
        <div class="invalid-feedback">
            <?php echo e($errors->first('libelserv')); ?>

        </div>
        <?php endif; ?>

        <label for="sigleserv">Sigle du service</label>
        <input type="text" name="sigleserv" class="form-control my-2 <?php if(!empty($errors->has('sigleserv'))): ?> is-invalid <?php endif; ?> " value="<?php echo e((!empty($service)) ? $service->sigleserv : old('sigleserv')); ?>" id="sigleserv" placeholder="Entrez le sigle du service">

        <?php if(!empty($errors->has('sigleserv'))): ?>
        <div class="invalid-feedback">
            <?php echo e($errors->first('sigleserv')); ?>

        </div>
        <?php endif; ?>

        <label for="marque">Type du Service</label>
        <select class="form-control" id="type" name="typeserv" class="form-control my-2 @error('typeserv') is-invalid @enderror  custom-select">
            <option value="">Choisir le Type du service</option>
            <option value="Technique" selected='selected'>Technique</option>
            <option value="Administratif">Administratif</option>   
            
            @error('typeserv')
            <div class="invalid-feedback">
                <?php echo e($errors->first('typeserv')); ?>

            </div>
            @enderror
        </select>

        <label for="marque">Rattachement du Service</label>
        <select class="form-control" id="type" name="rattachserv" class="form-control my-2 @error('rattachserv') is-invalid @enderror  custom-select">
            <option value="">Choisir le Rattachement du service</option>
            <option value="DG" selected='selected'>DG</option>
            <option value="DGA">DGA</option>   
            
            @error('rattachserv')
            <div class="invalid-feedback">
                <?php echo e($errors->first('rattachserv')); ?>

            </div>
            @enderror
        </select>

    </div>

    <button type="submit" class="btn btn-primary mr-2">VALIDER</button>

