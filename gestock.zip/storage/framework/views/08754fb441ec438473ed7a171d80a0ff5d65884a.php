<?php $__env->startSection('content'); ?>

<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="card col-md-12">
                  <div class="card-body">
                    <h4 class="card-title">Ajouter un  produit</h4>
                     <?php if(session('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <button type="button" class="close" aria-label="Close" @click="close" id="close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                          <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                     <?php if(session('danger')): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <button type="button" class="close" aria-label="Close" id="close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                          <?php echo e(session('danger')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="row">
                      <div class="col-md-12">
                       
                        <form action="<?php echo e(route('produits.update', $produit->id)); ?>" method="POST" class="form-sample" enctype="multipart/form-data" >
                           <?php echo csrf_field(); ?>
                           <?php echo method_field('PATCH'); ?>
                          
                           <?php echo $__env->make('produits/form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                           <button class="btn btn-primary" type="submit">  Enregistrer </button>
                        </form>
                       
                        </div>
                    </div>
                  </div>
                </div>
              </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>