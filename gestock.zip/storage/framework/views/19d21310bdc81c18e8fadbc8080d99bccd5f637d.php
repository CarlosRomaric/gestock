<?php $__env->startSection('content'); ?>
 <div class="container-scroller">
<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="container-fluid page-body-wrapper">
    <div class="main-panel">
    <div class="content-wrapper">
          <div class="row">
            <div class="col-md-6 offset-md-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Enregistrement des Ecoles</h4>
                  <p class="card-description">
                    <a href="<?php echo e(route('ecole.index')); ?>" class="btn btn-primary">LISTE</a>
                  </p>
                   <form class="forms-sample" action="<?php echo e(route('ecole.update', $ecoles->idecole)); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <?php echo $__env->make('ecole/form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                      <input type="hidden" name="_method" value="PATCH">
                   </form>
                </div>
              </div>
            </div>
           
          </div>
        </div>

    <?php echo $__env->make('inc/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>