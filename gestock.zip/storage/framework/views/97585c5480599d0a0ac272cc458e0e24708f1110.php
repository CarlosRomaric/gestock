<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="card">
                  <div class="card-body">
                    <?php if(session('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <button type="button" class="close" aria-label="Close" id="close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                          <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <h3 class="card-title text-center text-uppercase mb-5">Liste des Retours d'Articles en stocks</h3>
                    <?php if(Auth::user()->role==0): ?>
                     <a href="<?php echo e(route('retourStocks.create')); ?>" class="btn btn-primary mb-3">Enregistrer un retour d'article en stock</a>
                    <?php endif; ?>
                     <div class="row">
                      <div class="col-12 table-responsive">
                          <table class="table table-bordered table-hover table-sm center" id="example2">
                            <thead >
                                <tr class="bg-secondary">
                                    <th>N°</th>
                                    <th class="text-center">Membre du Staff</th>
                                    <th class="text-center">Agent Receptionneur</th>
                                    <th class="text-center">Date</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>

                                    <?php $__currentLoopData = $retourStocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retourStock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($retourStock->id); ?></td>
                                            <td class="text-center"><?php echo e($retourStock->technicien->nom); ?> <?php echo e($retourStock->technicien->prenoms); ?></td>
                                            <td class="text-center text-uppercase"><?php echo e($retourStock->user->name); ?>  </td>
                                            <td class="text-center"><?php echo e($retourStock->created_at->format('d/m/Y')); ?> </td>
                                            <td class="text-center">
                                                    <a href="retourStocks/<?php echo e($retourStock->id); ?>" class="btn btn-warning" title="Voir les détails du retour en stock"><i class="icon-eye"></i></a>
                                                    <a href="<?php echo e(route('pdf.listingRetourStocks', $retourStock->id)); ?>" title="Imprimer la liste du retour en Stock" class="btn btn-success"><i class="icon-printer"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                          </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>