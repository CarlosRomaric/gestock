
                    
    <div class="form-group">
        <label for="libtypdiplom">Libelle du Type de diplome</label>
        <input type="text" name=libtypdiplom" class="form-control my-2 <?php if(!empty($errors->has('libtypdiplom'))): ?> is-invalid <?php endif; ?> " value="<?php echo e((!empty($typediplome)) ? $typediplome->libtypdiplom : old('libtypdiplom')); ?>" id="libtypdiplom" placeholder="Entrez le libelle du Type de diplome">
        
        <?php if(!empty($errors->has('libtypdiplom'))): ?>
        <div class="invalid-feedback">
            <?php echo e($errors->first('libtypdiplom')); ?>

        </div>
        <?php endif; ?>
    </div>

    <label for="marque">Niveau d'etude</label>

        <select class="form-control" id="idniveau" name="idniveau" class="form-control my-2 @error('idniveau') is-invalid @enderror  custom-select" multiple>
            <option value="<?php echo e($niveauxetude->idniveau); ?>"><?php echo e($niveauxetude->libelniveau); ?>

            </option>
            
            @error('idniveau')
            <div class="invalid-feedback">
                <?php echo e($errors->first('idniveau')); ?>

            </div>
            @enderror
        </select>
    
    <button type="submit" class="btn btn-primary mr-2">VALIDER</button>

