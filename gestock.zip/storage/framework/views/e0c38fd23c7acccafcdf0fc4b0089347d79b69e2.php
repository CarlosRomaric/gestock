  <!-- partial:partials/_footer.html -->
  <footer class="footer">
    <div class="w-100 clearfix">
      <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018 <a href="../../index.html" target="_blank">Urbanui</a>. All rights reserved.</span>
      <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="icon-heart text-danger"></i></span>
    </div>
  </footer>
  <!-- partial -->