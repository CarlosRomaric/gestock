<div class="row">
    <div class="col-md-6">

        <div class="form-group row">
            <lablel for="nom_beneficiaire" class="col-sm-4 col-form-label">Nom du beneficiaire</lablel>
            <div class="col-sm-8">
                <select class="js-example-basic-single w-100" name="member_id">
                    <option value="">Ajouter le nom du bénéficiare</option>
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($member->id); ?>"><?php echo e($member->nom); ?> <?php echo e($member->prenoms); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                 <br>
                <?php if(!empty($errors->has('member_id'))): ?>
                <div class="mt-4 alert alert-danger">
                    <?php echo e($errors->first('member_id')); ?>

                </div>
                <?php endif; ?>
                      
            </div>
             
        </div>

       
    </div>
   

    <div class="col-md-6">
        <div class="form-group row">
            <lablel class="col-sm-4 col-form-lablel" for="objet">Objet de la cotisation</lablel>
            <div class="col-sm-8">
                <input type="text" name="objet" class="form-control" placeholder="Entrer l'objet de la cotisation">
                <br>
                <?php if(!empty($errors->has('objet'))): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first('objet')); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
       
    </div>
</div>



