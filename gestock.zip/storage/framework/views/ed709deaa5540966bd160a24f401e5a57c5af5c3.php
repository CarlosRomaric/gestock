<div class="row">
    <div class="col-md-12">

        <div class="form-group row">
            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
            <label for="technicien_id" class="col-sm-3 col-form-label">Membre du Staff</label>
            <div class="col-sm-9">
              <select name="technicien_id"  class="js-example-basic-single w-100" id="">
                  <option value="">Choisissez le membre du staff retournant le produit </option>
                  <?php $__currentLoopData = $techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $technicien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($key); ?>" class="text-uppaercase"    ><label for="" class="text-uppercase"><?php echo e($technicien); ?></label></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <br>
              <?php if(!empty($errors->has('technicien_id'))): ?>
              <div class="alert alert-danger mt-4">
                  <?php echo e($errors->first('technicien_id')); ?>

              </div>
              <?php endif; ?>
            </div>
        </div>

        <div class=" form-group  table-responsive">
            <label for="" class="label-form-group">Liste des Produits en Stocks</label>
            <table class="table table-bordered" id="example2">
                <thead>
                    <tr>
                        <th>Reférence</th>
                        <th>Image</th>
                        <th>Designation</th>
                        <th>Stock</th>
                        <th>Cocher les produit pour le retour</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($produit->ref); ?></td>
                        <td> <img src="/images_produits/<?php echo e($produit->image); ?>" alt=""></td>
                        <td><?php echo e($produit->designation); ?></td>
                        <td><?php echo e($produit->qteStock); ?></td>
                        <td scope="rows">
                            <div class="form-group row">
                                <div class="col-sm-1">
                                    <input type="checkbox" class="" name="produit_id[]" value="<?php echo e($produit->id); ?>">
                                </div>
                                <div class="col-sm-5">
                                    <input type="text" name="qteStock[<?php echo e($produit->id); ?>]" onkeypress="chiffres(event)" class="  form-control" placeholder="Entrez la quantité rétourné">
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" name="poids[<?php echo e($produit->id); ?>]" onkeypress="chiffres(event)" class="  form-control" placeholder="Entrez le poids du produit">
                                </div>
                            </div>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

    </div>

</div>















