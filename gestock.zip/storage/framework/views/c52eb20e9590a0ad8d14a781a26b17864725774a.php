
                    
    <div class="form-group">
        <label for="libelgpemploi">Nom du groupe d'emploi</label>
        <input type="text" name="libelgpemploi" class="form-control my-2 <?php if(!empty($errors->has('libelgpemploi'))): ?> is-invalid <?php endif; ?> " value="<?php echo e((!empty($groupeemploi)) ? $groupeemploi->libelgpemploi : old('libelgpemploi')); ?>" id="libelgpemploi" placeholder="Entrez le libelle du groupe emploi">
        
        <?php if(!empty($errors->has('libelgpemploi'))): ?>
        <div class="invalid-feedback">
            <?php echo e($errors->first('libelgpemploi')); ?>

        </div>
        <?php endif; ?>

        
    </div>

    <button type="submit" class="btn btn-primary mr-2">VALIDER</button>

