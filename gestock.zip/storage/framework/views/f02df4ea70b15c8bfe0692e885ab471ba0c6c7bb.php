<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="card">
                  <div class="card-body">
                    <?php if(session('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <button type="button" class="close" aria-label="Close" id="close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                          <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>

                     <?php if(session('danger')): ?>
                        <div class="alert alert-danger alert-dismissible fade show text-center col-md-4 offset-md-4">
                            <button type="button" class="close" aria-label="Close" id="close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                          <?php echo e(session('danger')); ?>

                        </div>
                    <?php endif; ?>

                    <h3 class="card-title text-center text-uppercase mb-5">Liste de produits</h3>
                     <a href="<?php echo e(route('cart.index')); ?>" class="btn btn-primary mb-3">Panier <span class="badge badge-pill badge-light text-primary"><?php echo e(Cart::count()); ?></span></a>
                    <div class="row">
                      <div class="col-12 table-responsive">
                          <table class="table table-bordered table-hover table-sm center" id="example2">
                            <thead >

                                <tr class=" bg-secondary">
                                    <th>N°</th>
                                    <th class="">Image</th>
                                    <th class="">Reférence</th>
                                    <th class="">Famille</th>
                                    <th class="">Marque</th>
                                    <th class="">Modele</th>
                                    <th class="">Fournisseur</th>
                                    <th class="">Designation</th>
                                    <th class="">Prix de Vente</th>

                                    <!--<th class="">Quantité</th>-->
                                    <th class="">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                    <?php $i=0; ?>
                                    <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $i++; ?>
                                        <tr class="text-center">
                                            <td><?php echo e($i); ?></td>
                                            <td class=""><img src="/images_produits/<?php echo e($produit->image); ?>" alt=""></td>
                                            <td class=""><?php echo e($produit->ref); ?> </td>
                                            <td class=""><?php echo e($produit->famille->libelle); ?></td>
                                            <td class=""><?php echo e($produit->famille->marque); ?></td>
                                            <td class=""><?php echo e($produit->famille->modele); ?></td>
                                            <td class=""><?php echo e($produit->fournisseur->nom); ?>  <?php echo e($produit->fournisseur->prenoms); ?> </td>
                                            <td class=""><?php echo e($produit->designation); ?> </td>
                                            <td class=""><?php echo e(getPrice($produit->priceSeller)); ?> </td>

                                            <form action="<?php echo e(route('cart.store')); ?>" method="POST">

                                                <?php echo csrf_field(); ?>
                                                <!--<td class="">
                                                    <input type="hidden" name="produit_id" value="<?php echo e($produit->id); ?>">
                                                    <input type="text" class="form-control small" name="qteStock" size="3" onkeypress=chiffres(event)>
                                                </td>-->
                                                <td class="">
                                                    <input type="hidden" name="produit_id" value="<?php echo e($produit->id); ?>">
                                                    <?php if($produit->qteStock <=0 ): ?>
                                                    <button class="btn btn-primary btn-sm" type="submit" disabled="disabled"> Choisir </button>
                                                    <?php else: ?>
                                                     <button class="btn btn-primary btn-sm" type="submit"> Choisir </button>
                                                    <?php endif; ?>
                                                </td>
                                            </form>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                          </table>

                      </div>
                    </div>
                  </div>
                </div>
              </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>