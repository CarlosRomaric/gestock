<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="card">
                    <div class="card-body">
                        <?php if(session('message')): ?>
                            <div class="alert alert-success alert-dismissible fade show">
                                <button type="button" class="close" aria-label="Close" id="close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            <?php echo e(session('message')); ?>

                            </div>
                        <?php endif; ?>
                        <h3 class="card-title text-center my-3 text-uppercase">Retour en Stock N°<?php echo e($retourStock->id); ?></h3>
                        <p class="mt-3">
                            <span class="text-uppercase"><label for=""><strong>Demandeur:  </strong> </label><?php echo e($retourStock->technicien->nom); ?> <?php echo e($retourStock->technicien->prenoms); ?></span>
                            <span class="float-right text-uppercase"><label for=""><strong>Magasinier </strong> </label>: <?php echo e($retourStock->user->name); ?></span><br>
                            <span class="text-uppercase"><label for=""><strong>Date</strong>: <?php echo e($retourStock->created_at->format('d/m/Y')); ?> à <?php echo e($retourStock->created_at->format('H:i:s')); ?> </label></span><br>
                        </p>
                        <div class="row">
                            <div class="col-12 table-responsive">
                                <table class="table table-bordered table-hover table-sm center">
                                  <thead >
                                      <tr class="bg-secondary">
                                          <th>N°</th>

                                          <th class="text-center">image</th>
                                          <th class="text-center">Reference</th>
                                          <th class="text-center">Designation</th>
                                          <th class="text-center">Famille</th>
                                          <th class="text-center">Modele</th>
                                          <th class="text-center">Marque</th>
                                          <th class="text-center">poids (kg)</th>
                                          <th class="text-center">Prix de Vente</th>
                                          <th class="text-center">Quantité</th>
                                          <th class="text-center">Prix</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                          <?php $i=0; ?>
                                          <?php $total=0; ?>
                                          <?php $prix=0; ?>                                          <?php $tab = []; ?>
                                          <?php $__currentLoopData = $retours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php $i++; ?>

                                          <?php $total +=  $retour->qteStock; ?>
                                          <?php $prix +=  ($retour->produit->priceSeller* $retour->qteStock); ?>
                                              <tr>
                                                  <td><?php echo e($i); ?></td>
                                                  <td class="text-center"><img src="/images_produits/<?php echo e($retour->produit->image); ?>" alt=""></td>
                                                  <td class="text-center"><?php echo e($retour->produit->ref); ?></td>
                                                  <td class="text-center"><?php echo e($retour->produit->designation); ?></td>
                                                  <td class="text-center"><?php echo e($retour->produit->famille->libelle); ?></td>
                                                  <td class="text-center"><?php echo e($retour->produit->famille->modele); ?></td>
                                                  <td class="text-center"><?php echo e($retour->produit->famille->marque); ?></td>
                                                  <td class="text-center"><?php echo e($retour->poids); ?></td>
                                                  <td class="text-center"><?php echo e(getPrice($retour->produit->priceSeller)); ?></td>
                                                  <td class="text-center"><?php echo e($retour->qteStock); ?></td>
                                                  <td class="text-center"><?php echo e(getPrice($retour->produit->priceSeller *  $retour->qteStock)); ?></td>
                                              </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                  </tbody>
                                  <tfoot>
                                  <tr class="bg-secondary">
                                      <td colspan="9" class="text-uppercase">Total</td>
                                      <td class="text-center"><?php echo e($total); ?></td>
                                      <td class="text-center"><?php echo e(getPrice($prix)); ?></td>
                                  </tr>

                                  </tfoot>
                                </table>


                                <a href="<?php echo e(route('pdf.listingRetourStocks', $retourStock->id)); ?>" class="btn btn-success my-3 "><i class="icon-printer"></i>Imprimer la liste du retour en Stock</a>

                            </div>
                          </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>