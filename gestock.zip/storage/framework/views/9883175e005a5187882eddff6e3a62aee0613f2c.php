<div class="form-group row">
          <label for="qteStock" class="col-sm-3 col-form-label">Quantité</label>
          <div class="col-sm-9">
            <input type="text" name="qteStock"  id="qteStock" class="form-control" value="" placeholder="Entrez le Quantité du produit" onkeypress="chiffres(event)">
            <br>
            <?php if(!empty($errors->has('qteStock'))): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('qteStock')); ?>

            </div>
            <?php endif; ?>
         </div>
</div>

<input type="hidden" name="produit_id" value="<?php echo e($produit->id); ?>">
<input type="hidden" name="user_id" value = "<?php echo e(Auth::user()->id); ?>">
<input type="hidden" name="date" value = "<?php echo e(date('Y-m-d H:i:s')); ?>">
