<?php echo $__env->make('inc/printerstyle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



   <div class="col-md-12 offest-2 mt-5">
      <div class="card mt-10">
        <div class="card-body">

          <h3 class="card-title text-center mb-5 text-uppercase">Liste des Familles d'Articles</h3>


          <div class="row">
            <div class="col-12 table-responsive">
                <table class="table table-bordered table-hover table-sm center" id="example2">
                    <thead >
                        <tr class="bg-dark text-white p-5">
                            <th>N°</th>
                            <th class="text-center">Libellé</th>
                            <th class="text-center">Marque</th>
                            <th class="text-center">Modele</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $i=0; ?>
                        <?php $__currentLoopData = $familles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $famille): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                            <tr class="p-5">
                                <td><?php echo e($i); ?></td>
                                <td class="text-center text-uppercase"><?php echo e($famille->libelle); ?> </td>
                                <td class="text-center text-uppercase"><?php echo e($famille->marque); ?> </td>
                                <td class="text-center text-uppercase"><?php echo e($famille->modele); ?> </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>

            </div>
          </div>
        </div>
      </div>
   </div>




