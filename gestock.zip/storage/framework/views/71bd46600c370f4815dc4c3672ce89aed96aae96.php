
<div class="form-group row">
          <label for="name" class="col-sm-3 col-form-label">Nom</label>
          <div class="col-sm-9">
            <input type="text" name="name"  id="libelle" class="form-control" value="<?php echo e((empty($user)) ? old('name') : $user->name); ?>" placeholder="Entrez le nom de l'utilisateur">
            <br>
            <?php if(!empty($errors->has('name'))): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('name')); ?>

            </div>
            <?php endif; ?>
         </div>
</div>

<div class="form-group row">
          <label for="email" class="col-sm-3 col-form-label">Email</label>   
          <div class="col-sm-9">
            <input type="text" name="email"  id="libelle" class="form-control" value="<?php echo e((empty($user)) ? old('email') : $user->email); ?>" placeholder="Entrez l'email">
            <br>
            <?php if(!empty($errors->has('email'))): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('email')); ?>

            </div>
            <?php endif; ?>
         </div>
</div>

<div class="form-group row">
          <label for="password" class="col-sm-3 col-form-label">Mot de passe</label>   
          <div class="col-sm-9">
            <input type="password" name="password"  id="password" class="form-control" value="" placeholder="Entrez le mot de passe">
            <br>
            <?php if(!empty($errors->has('password'))): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('password')); ?>

            </div>
            <?php endif; ?>
         </div>
</div>

<div class="form-group row">
          <label for="password" class="col-sm-3 col-form-label">Confirmation du mot de passe</label>   
          <div class="col-sm-9">
            <input type="password" name="password_confirmation"  id="password" class="form-control" value="" placeholder="confirmer le mot de passe">
            <br>
            <?php if(!empty($errors->has('password'))): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first('password')); ?>

            </div>
            <?php endif; ?>
         </div>
</div>
<!--<div class="form-group form-check row ml-4">
        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
        <label class="form-check-label" for="remember">
            Se souvenir de moi
        </label>

</div>-->

<div class="form-group row">
 <label for="Libelle" class="col-sm-3 col-form-label">Role</label>
   <div class="col-sm-9">
        <select name="role" id="role" class="form-control" id="formselect2">
           <?php if((Auth::user()->role === 0)): ?>
            <option value="0">Admin</option>
           <?php endif; ?>
            <option value="1">Trésorier</option>
            <option value="2">Président</option>
        </select>
    </div>
</div>