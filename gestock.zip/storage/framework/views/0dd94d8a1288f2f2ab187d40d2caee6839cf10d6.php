  <!-- partial:partials/_footer.html -->
  <footer class="footer">
    <div class="w-100 clearfix">
      <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2020 <a href="/" target="_blank">AREA</a>. Tous droits réservés.</span>
      <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">une solution dévéloppé par ict4dev <i class="icon-heart text-danger"></i></span>
    </div>
  </footer>
  <!-- partial -->