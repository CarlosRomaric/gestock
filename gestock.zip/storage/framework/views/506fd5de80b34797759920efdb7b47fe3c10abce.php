<?php $__env->startSection('content'); ?>

<?php echo $__env->make('inc/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="card col-md-12 ">
                  <div class="card-body">
                    <h4 class="card-title mb-4">Ajouter une cotisation exceptionnel </h4>
                    <div class="row">
                      <div class="col col-md-12 ">
                      
                        <form action="<?php echo e(route('cotisationExceptionnel.store')); ?>" method="POST" class="form-sample" >
                           <?php echo csrf_field(); ?>
                           <?php echo $__env->make('cotisationExceptionnel/form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                           <button class="btn btn-primary" type="submit">  Enregistrer </button>
                        </form>
                       
                        </div>
                    </div>
                  </div>
                </div>
              </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>